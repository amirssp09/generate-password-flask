from flask import Flask, render_template, request
import string
import random

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/generate", methods=["POST"])
def generate_password():
    try:
        # دریافت طول رمز از فرم HTML
        length = int(request.form.get("length"))

        if length < 4:
            return render_template("index.html")

        # تعریف مجموعه کاراکترها
        lower = string.ascii_lowercase
        upper = string.ascii_uppercase
        digits = string.digits
        symbols = string.punctuation

        # تضمین حداقل یک کاراکتر از هر نوع
        password = [
            random.choice(lower),
            random.choice(upper),
            random.choice(digits),
            random.choice(symbols),
        ]

        # پر کردن باقی‌مانده با کاراکترهای تصادفی
        all_chars = lower + upper + digits + symbols
        for _ in range(length - 4):
            password.append(random.choice(all_chars))

        #برزدن کاراکترها
        random.shuffle(password)

        # تبدیل لیست به رشته
        final_password = "".join(password)

        # نمایش در صفحه
        return render_template("index.html", password=final_password, length=length)

    except (ValueError, TypeError):
        return render_template("index.html")

if __name__ == "__main__":
    app.run()
